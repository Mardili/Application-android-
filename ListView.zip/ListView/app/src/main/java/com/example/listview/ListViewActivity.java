package com.example.listview;

import static android.R.layout.simple_list_item_1;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;


public class ListViewActivity extends AppCompatActivity {
String []city={"اراک","قم","تهران","اصفهان","شیراز"};
String []tel = new String[]{"086","اطلاعی ندارم","025","021","031","061"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);


        ListView listView=findViewById(R.id.listView);

        ArrayAdapter adapter=new ArrayAdapter(this, ,city);

        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    Toast.makeText(ListViewActivity.this,"پیش شماره "+tel[i], Toast.LENGTH_SHORT).show();



            }
        }
    }
}




